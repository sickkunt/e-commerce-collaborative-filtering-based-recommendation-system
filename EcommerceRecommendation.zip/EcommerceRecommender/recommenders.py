import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
import logging
import os
import time
import math
from numpy.random import RandomState

use_deep_learning = True
deep_learning_model = None

ratings_df = None
user_based_similarity = None
item_based_similarity = None
matrix_fact_model = None
user_factors = None
item_factors = None
user_mapping = None
item_mapping = None
reverse_user_mapping = None
reverse_item_mapping = None

def load_data():
    global ratings_df
    dataset_path = os.path.join('attached_assets', 'preprocessed_dataset1.csv')
    try:
        ratings_df = pd.read_csv(dataset_path)
        logging.info(f"Full dataset loaded with shape: {ratings_df.shape}")
    except Exception as e:
        logging.error(f"Error loading dataset: {e}")
        data = {
            'UserId': ['U1', 'U1', 'U2', 'U2', 'U3'],
            'ProductId': ['P1', 'P2', 'P2', 'P3', 'P1'],
            'Rating': [5, 4, 5, 3, 4],
            'Timestamp': [1000, 1001, 1002, 1003, 1004]
        }
        ratings_df = pd.DataFrame(data)
        logging.warning("Using fallback sample data since dataset couldn't be loaded")
    ratings_df['UserId'] = ratings_df['UserId'].astype(str)
    ratings_df['ProductId'] = ratings_df['ProductId'].astype(str)
    
    return ratings_df

def create_user_item_matrix():
    if ratings_df is None:
        load_data()
    user_item_matrix = ratings_df.pivot_table(
        index='UserId', 
        columns='ProductId', 
        values='Rating',
        fill_value=0
    )
    
    return user_item_matrix

def train_user_based_model():
    global user_based_similarity
    user_item_matrix = create_user_item_matrix()
    user_based_similarity = cosine_similarity(user_item_matrix)
    user_based_similarity = pd.DataFrame(
        user_based_similarity,
        index=user_item_matrix.index,
        columns=user_item_matrix.index
    )
    
    logging.info("User-based collaborative filtering model trained")

def train_item_based_model():
    global item_based_similarity
    user_item_matrix = create_user_item_matrix()
    item_based_similarity = cosine_similarity(user_item_matrix.T)
    item_based_similarity = pd.DataFrame(
        item_based_similarity,
        index=user_item_matrix.columns,
        columns=user_item_matrix.columns
    )
    
    logging.info("Item-based collaborative filtering model trained")

def create_mapping_dictionaries():
    global user_mapping, item_mapping, reverse_user_mapping, reverse_item_mapping
    
    if ratings_df is None:
        load_data()
    unique_users = ratings_df['UserId'].unique()
    user_mapping = {user: i for i, user in enumerate(unique_users)}
    reverse_user_mapping = {i: user for user, i in user_mapping.items()}
    unique_products = ratings_df['ProductId'].unique()
    item_mapping = {product: i for i, product in enumerate(unique_products)}
    reverse_item_mapping = {i: product for product, i in item_mapping.items()}
    
    logging.info(f"Created mappings for {len(user_mapping)} users and {len(item_mapping)} items")

class NumpyNeuralCollaborativeFiltering:
    
    def __init__(self, n_users, n_items, n_factors=20, learning_rate=0.01, reg_lambda=0.01, random_state=42):
        self.n_users = n_users
        self.n_items = n_items
        self.n_factors = n_factors
        self.learning_rate = learning_rate
        self.reg_lambda = reg_lambda  
        self.rng = RandomState(random_state)
        self.user_factors = self.rng.normal(0, 0.1, (n_users, n_factors))
        self.item_factors = self.rng.normal(0, 0.1, (n_items, n_factors))
        self.W1 = self.rng.normal(0, 0.1, (2 * n_factors, 32))
        self.b1 = np.zeros(32)
        self.W2 = self.rng.normal(0, 0.1, (32, 16))
        self.b2 = np.zeros(16)
        self.W3 = self.rng.normal(0, 0.1, (16, 1))
        self.b3 = np.zeros(1)
        
    def _sigmoid(self, x):
        return 1.0 / (1.0 + np.exp(-np.clip(x, -15, 15)))
    
    def _relu(self, x):
        return np.maximum(0, x)
    
    def predict(self, user_idx, item_idx):
        user_embedding = self.user_factors[user_idx]
        item_embedding = self.item_factors[item_idx]
        x = np.concatenate([user_embedding, item_embedding])
        h1 = self._relu(np.dot(x, self.W1) + self.b1)
        h2 = self._relu(np.dot(h1, self.W2) + self.b2)
        output = self._sigmoid(np.dot(h2, self.W3) + self.b3)
        return 5.0 * output[0]
    
    def _compute_gradients(self, user_idx, item_idx, target, prediction):
        user_embedding = self.user_factors[user_idx]
        item_embedding = self.item_factors[item_idx]
        x = np.concatenate([user_embedding, item_embedding])
        z1 = np.dot(x, self.W1) + self.b1
        h1 = self._relu(z1)
        z2 = np.dot(h1, self.W2) + self.b2
        h2 = self._relu(z2)
        z3 = np.dot(h2, self.W3) + self.b3
        output = self._sigmoid(z3)
        scaled_target = target / 5.0
        error = output - scaled_target
        delta3 = error * output * (1 - output)
        grad_W3 = np.outer(h2, delta3)
        grad_b3 = delta3
        delta2 = np.dot(delta3, self.W3.T) * (h2 > 0).astype(float)
        grad_W2 = np.outer(h1, delta2)
        grad_b2 = delta2
        delta1 = np.dot(delta2, self.W2.T) * (h1 > 0).astype(float)
        grad_W1 = np.outer(x, delta1)
        grad_b1 = delta1
        delta_input = np.dot(delta1, self.W1.T)
        grad_user_factors = delta_input[:self.n_factors]
        grad_item_factors = delta_input[self.n_factors:]
        grad_user_factors += self.reg_lambda * user_embedding
        grad_item_factors += self.reg_lambda * item_embedding
        grad_W1 += self.reg_lambda * self.W1
        grad_W2 += self.reg_lambda * self.W2
        grad_W3 += self.reg_lambda * self.W3
        
        return {
            'user_factors': grad_user_factors,
            'item_factors': grad_item_factors,
            'W1': grad_W1,
            'b1': grad_b1,
            'W2': grad_W2,
            'b2': grad_b2,
            'W3': grad_W3,
            'b3': grad_b3
        }
    
    def update_parameters(self, gradients, user_idx, item_idx):
        self.user_factors[user_idx] -= self.learning_rate * gradients['user_factors']
        self.item_factors[item_idx] -= self.learning_rate * gradients['item_factors']
        self.W1 -= self.learning_rate * gradients['W1']
        self.b1 -= self.learning_rate * gradients['b1']
        self.W2 -= self.learning_rate * gradients['W2']
        self.b2 -= self.learning_rate * gradients['b2']
        self.W3 -= self.learning_rate * gradients['W3']
        self.b3 -= self.learning_rate * gradients['b3']
    
    def fit(self, user_indices, item_indices, ratings, epochs=5, batch_size=64, verbose=True):
        n_samples = len(ratings)
        indices = np.arange(n_samples)
        
        for epoch in range(epochs):
            self.rng.shuffle(indices)
            epoch_loss = 0.0
            start_time = time.time()
            for start_idx in range(0, n_samples, batch_size):
                batch_indices = indices[start_idx:min(start_idx + batch_size, n_samples)]
                batch_users = user_indices[batch_indices]
                batch_items = item_indices[batch_indices]
                batch_ratings = ratings[batch_indices]
                
                batch_loss = 0.0
                for i in range(len(batch_ratings)):
                    user_idx = batch_users[i]
                    item_idx = batch_items[i]
                    rating = batch_ratings[i]
                    prediction = self.predict(user_idx, item_idx)
                    error = prediction - rating
                    batch_loss += error ** 2
                    gradients = self._compute_gradients(
                        user_idx, item_idx, rating, prediction / 5.0
                    )
                    self.update_parameters(gradients, user_idx, item_idx)
                
                epoch_loss += batch_loss
            avg_epoch_loss = epoch_loss / n_samples
            
            if verbose and (epoch % 1 == 0 or epoch == epochs - 1):
                end_time = time.time()
                logging.info(f"Epoch {epoch+1}/{epochs} - Loss: {avg_epoch_loss:.4f} - Time: {end_time - start_time:.2f}s")
                
        return self
        
def train_deep_learning_model():
    global deep_learning_model, user_mapping, item_mapping, user_factors, item_factors
    
    if ratings_df is None:
        load_data()
    if user_mapping is None or item_mapping is None:
        create_mapping_dictionaries()
    user_indices = np.array([user_mapping[user_id] for user_id in ratings_df['UserId']])
    item_indices = np.array([item_mapping[product_id] for product_id in ratings_df['ProductId']])
    ratings = ratings_df['Rating'].values
    max_samples = 10000  
    if len(ratings) > max_samples:
        sample_indices = np.random.choice(len(ratings), max_samples, replace=False)
        user_indices = user_indices[sample_indices]
        item_indices = item_indices[sample_indices]
        ratings = ratings[sample_indices]
    n_users = len(user_mapping)
    n_items = len(item_mapping)
    n_factors = 20  
    
    logging.info(f"Training deep learning model with {len(ratings)} ratings")
    logging.info(f"Model has {n_users} users, {n_items} items, and {n_factors} factors")
    model = NumpyNeuralCollaborativeFiltering(
        n_users=n_users,
        n_items=n_items,
        n_factors=n_factors,
        learning_rate=0.01,
        reg_lambda=0.01
    )
    start_time = time.time()
    model.fit(
        user_indices=user_indices,
        item_indices=item_indices,
        ratings=ratings,
        epochs=3, 
        batch_size=128,
        verbose=True
    )
    
    end_time = time.time()
    logging.info(f"Deep learning model trained in {end_time - start_time:.2f} seconds")
    
    deep_learning_model = model
    user_factors = model.user_factors  
    item_factors = model.item_factors  
    
    return model

def get_user_based_recommendations(user_id, top_n=5):
    global user_based_similarity
    
    if user_based_similarity is None:
        train_user_based_model()
    if user_id not in user_based_similarity.index:
        raise ValueError(f"User ID '{user_id}' not found in the dataset.")
    user_item_matrix = create_user_item_matrix()
    user_similarities = user_based_similarity.loc[user_id]
    
    user_rated_items = user_item_matrix.loc[user_id]
    unrated_items = user_rated_items[user_rated_items == 0].index
    
    
    item_scores = {}
    for item in unrated_items:
        item_raters = user_item_matrix[item]
        item_raters = item_raters[item_raters > 0].index
        
        if len(item_raters) == 0:
            continue
        similarities = user_similarities[item_raters]
        ratings = user_item_matrix.loc[item_raters, item]
        if sum(similarities) == 0:
            continue
        predicted_rating = sum(similarities * ratings) / sum(similarities)
        item_scores[item] = predicted_rating
    recommended_items = sorted(item_scores.items(), key=lambda x: x[1], reverse=True)[:top_n]
    recommendations = [
        {
            'product_id': item,
            'predicted_rating': round(score, 2)
        }
        for item, score in recommended_items
    ]
    
    return recommendations

def get_item_based_recommendations(product_id, top_n=5):
    global item_based_similarity
    
    if item_based_similarity is None:
        train_item_based_model()
    if product_id not in item_based_similarity.index:
        raise ValueError(f"Product ID '{product_id}' not found in the dataset.")
    item_similarities = item_based_similarity.loc[product_id]
    similar_items = item_similarities.drop(product_id).sort_values(ascending=False).head(top_n)
    recommendations = [
        {
            'product_id': item,
            'similarity_score': round(score, 2)
        }
        for item, score in similar_items.items()
    ]
    
    return recommendations

def get_deep_learning_recommendations(user_id, top_n=5):
    global ratings_df, deep_learning_model, user_mapping, item_mapping
    
    if ratings_df is None:
        load_data()
    if deep_learning_model is None:
        if use_deep_learning and user_mapping is not None and item_mapping is not None:
            try:
                train_deep_learning_model()
            except Exception as e:
                logging.error(f"Error training deep learning model: {e}")
                logging.warning("Falling back to hybrid recommendation method")
        if deep_learning_model is None:
            return get_hybrid_recommendations(user_id, top_n)
    if user_id not in user_mapping:
        logging.warning(f"User ID '{user_id}' not found in deep learning model. Using hybrid approach.")
        return get_hybrid_recommendations(user_id, top_n)
        
    try:
        user_idx = user_mapping[user_id]
        user_item_matrix = create_user_item_matrix()
        user_rated_items = set()
        
        try:
            if user_id in user_item_matrix.index:
                user_ratings = user_item_matrix.loc[user_id]
                user_rated_items = set(user_ratings[user_ratings > 0].index)
        except:
            user_rated_df = ratings_df[ratings_df['UserId'] == user_id]
            user_rated_items = set(user_rated_df['ProductId'].values)
        all_items = set(item_mapping.keys())
        unrated_items = all_items - user_rated_items
        
        item_scores = {}
        for item_id in unrated_items:
            if item_id in item_mapping:
                item_idx = item_mapping[item_id]
                predicted_rating = deep_learning_model.predict(user_idx, item_idx)
                item_scores[item_id] = predicted_rating
        recommended_items = sorted(item_scores.items(), key=lambda x: x[1], reverse=True)[:top_n]
        recommendations = [
            {
                'product_id': item_id,
                'predicted_rating': round(score, 2),
                'method': 'deep_learning'
            }
            for item_id, score in recommended_items
        ]
        
        if len(recommendations) < top_n:
            logging.info(f"Deep learning model only found {len(recommendations)} items. Adding hybrid recommendations.")
            hybrid_recs = get_hybrid_recommendations(user_id, top_n - len(recommendations))
            existing_ids = {rec['product_id'] for rec in recommendations}
            for rec in hybrid_recs:
                if rec['product_id'] not in existing_ids:
                    rec['method'] = 'hybrid'
                    recommendations.append(rec)
                    if len(recommendations) >= top_n:
                        break
        
        return recommendations
        
    except Exception as e:
        logging.error(f"Error getting deep learning recommendations: {e}")
        logging.warning("Falling back to hybrid recommendation method")
        return get_hybrid_recommendations(user_id, top_n)
        
def get_hybrid_recommendations(user_id, top_n=5):
    global ratings_df, user_based_similarity, item_based_similarity
    
    if ratings_df is None:
        load_data()
    if user_based_similarity is None:
        train_user_based_model()
    
    if item_based_similarity is None:
        train_item_based_model()
    
    user_based_recs = []
    try:
        user_based_recs = get_user_based_recommendations(user_id, top_n=top_n*2)
    except ValueError:
        logging.info(f"User ID '{user_id}' not found in user-based model")
    try:
        user_ratings = ratings_df[ratings_df['UserId'] == user_id]
        
        if len(user_ratings) > 0:
            top_rated = user_ratings.sort_values('Rating', ascending=False).head(3)
            similar_items = {}
            for _, row in top_rated.iterrows():
                product_id = row['ProductId']
                try:
                    similar = get_item_based_recommendations(product_id, top_n=3)
                    for item in similar:
                        pid = item['product_id']
                        score = item['similarity_score'] * row['Rating'] / 5.0
                        if pid in similar_items:
                            similar_items[pid] = max(similar_items[pid], score)
                        else:
                            similar_items[pid] = score
                except ValueError:
                    pass
            item_based_recs = [
                {'product_id': pid, 'predicted_rating': score}
                for pid, score in similar_items.items()
            ]
            item_based_recs.sort(key=lambda x: x['predicted_rating'], reverse=True)
        else:
            item_based_recs = []
    except Exception as e:
        logging.error(f"Error getting content-based recommendations: {e}")
        item_based_recs = []
    product_stats = ratings_df.groupby('ProductId').agg({'Rating': ['mean', 'count']})
    product_stats.columns = ['avg_rating', 'num_ratings']
    popular_products = product_stats[product_stats['num_ratings'] >= 5].sort_values(
        by=['avg_rating', 'num_ratings'], ascending=False
    ).head(top_n)
    
    popularity_recs = [
        {
            'product_id': idx,
            'predicted_rating': round(row['avg_rating'], 2)
        }
        for idx, row in popular_products.iterrows()
    ]
    
    all_recommendations = {}
    
    for i, rec in enumerate(user_based_recs):
        pid = rec['product_id']
        weight = 1.0 * (1.0 - i / (2 * top_n + 1))
        all_recommendations[pid] = rec['predicted_rating'] * weight
    
    for i, rec in enumerate(item_based_recs):
        pid = rec['product_id']
    
        if pid not in all_recommendations:
            weight = 0.8 * (1.0 - i / (len(item_based_recs) + 1))
            all_recommendations[pid] = rec['predicted_rating'] * weight
    

    for i, rec in enumerate(popularity_recs):
        pid = rec['product_id']
  
        if pid not in all_recommendations:
            weight = 0.6 * (1.0 - i / (len(popularity_recs) + 1))
            all_recommendations[pid] = rec['predicted_rating'] * weight
    

    final_recs = sorted(all_recommendations.items(), key=lambda x: x[1], reverse=True)[:top_n]
    
    recommendations = [
        {
            'product_id': item,
            'predicted_rating': round(score, 2),
            'method': 'hybrid'
        }
        for item, score in final_recs
    ]
    
    return recommendations

def initialize_models():
   

    load_data()
    

    train_user_based_model()
    

    train_item_based_model()
    

    if use_deep_learning:
        try:
            create_mapping_dictionaries()
            train_deep_learning_model()
            logging.info("All models initialized including deep learning")
        except Exception as e:
            logging.error(f"Error initializing deep learning model: {e}")
            logging.info("Using enhanced hybrid method as alternative to deep learning")
    else:
        logging.info("Using enhanced hybrid method as alternative to deep learning")
    
    logging.info("Recommendation models initialized successfully")
